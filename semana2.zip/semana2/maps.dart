void  main (){
  var regalos = {
    //key        Value
  'primero':   'celular android',
  'segundo':   'ipad',
  'tercero':   'bicicleta'
};

var calificacion = {
  2: 'malo',
  5: 'bueno',
  9:'muy bueno'
};

print (regalos);
print('El primer regalo es: ${regalos['primero']}');

print(calificacion);

print ('La calificacion en la poblacion 2 es: ${calificacion[5]}');
}