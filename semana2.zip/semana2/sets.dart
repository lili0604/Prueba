void main(){
  var colores = {'azul', 'verde', 'morado', 'purpura', 'rojo'};

  print(
    'la lista de colores es: ${colores}'); //el metodo elementAt permite acceder a la posicion

    colores.forEach((color) { 
      print (color);
    });
} 