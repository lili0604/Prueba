void main (){
    var nombreCompleto = "";
    assert(nombreCompleto.isEmpty);

    var unicorn = null;
    assert(unicorn == null);
    if (unicorn == true){
        print ("El valor es verdero");
    } else{
        print("El valor es falso o no esta establecido");
    }
}
