void main (){
  List<String> nombres;
  nombres = <String>[];

  String nombre1 = "Pedro";
  String nombre2 = "Pablo";
  String nombre3 = "Juan";

  nombres.add(nombre1);
  nombres.add(nombre2);
  nombres.add(nombre3);

  print (nombres);
  nombres.forEach((nombre) { 
    print('El nombre es : $nombre');
  });

  print ('Imprimir con funcion flecha');
  nombres.forEach((nombre) => print ('El nombre es: $nombre'));
}