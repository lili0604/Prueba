void main (){
  var edades = [25,45,78];

  var animales = ['perro', 'gato', 'araña', 'gallina'];

  print ('la lista de animales es ${animales}');

  print ('la lista de edades es ${edades}');
}