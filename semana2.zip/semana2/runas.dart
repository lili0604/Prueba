void main(){
  var hi ='Hola';
  print (hi);

  var uppercaseM = '\u{004d}';
  print(uppercaseM);

  //Unicode equivalent of the digit 7
  var seven = '\u{0037}';
  print(seven);

  //Unicode equivalent of the dollar sign
  var dollarSign = '\u{0024}';
  print (dollarSign);

  //Unicode equivalent of the thumbs-up emoji
  var thumbsUp='\u{1f44d}';
  print (thumbsUp);
}